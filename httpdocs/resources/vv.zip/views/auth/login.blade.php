@extends('layouts.landing')
@section('title','Sign in — Woork')
@section('content')
<div class="max-w-md mx-auto px-4 py-16">
  <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-6 shadow-sm">
    <h1 class="text-lg font-semibold mb-1">Sign in with WhatsApp OTP</h1>
    <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">We’ll send a one-time code to your phone.</p>
    <form method="POST" action="{{ route('otp.request') }}" class="space-y-3">@csrf
      <label class="block text-sm font-medium">Phone (WhatsApp)</label>
      <input name="phone" placeholder="+1 202 555 0142" class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-slate-800 placeholder-slate-400 shadow-sm focus:border-emerald-500 focus:ring-emerald-300 dark:bg-slate-900 dark:text-slate-100 dark:border-slate-700">
      <button class="w-full rounded-xl bg-emerald-600 text-white px-4 py-2">Send code</button>
    </form>
  </div>
</div>
@endsection
