@extends('layouts.landing')
@section('title','Enter code — Woork')
@section('content')
<div class="max-w-md mx-auto px-4 py-16">
  <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-6 shadow-sm">
    <h1 class="text-lg font-semibold mb-4">Enter the 6-digit code</h1>
    <form method="POST" action="{{ route('otp.verify') }}" class="space-y-3">@csrf
      <input type="hidden" name="phone" value="{{ old('phone',$phone ?? '') }}">
      <input name="code" placeholder="••••••" class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-slate-800 placeholder-slate-400 shadow-sm focus:border-emerald-500 focus:ring-emerald-300 dark:bg-slate-900 dark:text-slate-100 dark:border-slate-700">
      <button class="w-full rounded-xl bg-emerald-600 text-white px-4 py-2">Verify & Continue</button>
    </form>
  </div>
</div>
@endsection
