@extends('layouts.app')
@section('title','Reports')
@section('page','Reports')
@section('content')
<x-card title="Daily CSV export">
  <form method="GET" action="{{ route('export.daily') }}" class="flex flex-wrap gap-3 items-end">
    <div><label class="block text-sm mb-1">Date</label><x-input type="date" name="date"/></div>
    <x-button>Download</x-button>
  </form>
</x-card>
@endsection
