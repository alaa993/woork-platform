@extends('layouts.app')
@section('title','Dashboard')
@section('page','Dashboard')
@section('content')
<div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
  @php $kpis=[
    ['Today Score', $today['score'] ?? 86],
    ['Active Employees', $today['active_employees'] ?? 12],
    ['Phone Events', $today['phone_count'] ?? 7],
    ['Away Events', $today['away_count'] ?? 3],
  ]; @endphp
  @foreach($kpis as [$label,$val])
    <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-5 shadow-sm">
      <div class="text-xs text-slate-500">{{ $label }}</div>
      <div class="mt-1 text-3xl font-semibold">{{ $val }}</div>
    </div>
  @endforeach
</div>
<div class="grid lg:grid-cols-2 gap-4 mt-6">
  <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-5">
    <div class="text-sm font-semibold mb-2">Weekly Score</div>
    <div class="h-64 grid place-items-center text-slate-400">Bind ApexCharts here</div>
  </div>
  <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-5">
    <div class="text-sm font-semibold mb-2">Recent Alerts</div>
    <ul class="divide-y divide-slate-200/70 dark:divide-white/10">
      @forelse(($alerts ?? []) as $alert)
        <li class="py-2 flex items-center justify-between">
          <div>
            <div class="font-medium">{{ $alert->message }}</div>
            <div class="text-xs text-slate-500">{{ $alert->kind }} · {{ $alert->channel }}</div>
          </div>
          <x-badge color="amber">{{ $alert->level }}</x-badge>
        </li>
      @empty
        <li class="py-6 text-center text-slate-400">No alerts.</li>
      @endforelse
    </ul>
  </div>
</div>
@endsection
