@extends('layouts.app')
@section('title','Policies')
@section('page','Policies')
@section('content')
<div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-5">
  <form method="POST" action="{{ route('policies.update') }}" class="grid md:grid-cols-2 gap-6">@csrf @method('PUT')
    <div>
      <label class="block text-sm mb-1">Save video</label>
      <select name="save_video" class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 dark:bg-slate-900 dark:border-slate-700">
        <option value="0" @selected(old('save_video',$policy->save_video ?? 0)==0)>Disabled</option>
        <option value="1" @selected(old('save_video',$policy->save_video ?? 0)==1)>Enabled</option>
      </select>
    </div>
    <div>
      <label class="block text-sm mb-1">Work hours (JSON)</label>
      <textarea name="work_hours" rows="8" class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 dark:bg-slate-900 dark:border-slate-700">{{ old('work_hours', json_encode($policy->work_hours ?? [], JSON_PRETTY_PRINT)) }}</textarea>
    </div>
    <div class="md:col-span-2"><button class="rounded-xl bg-emerald-600 text-white px-4 py-2">Save</button></div>
  </form>
</div>
@endsection
