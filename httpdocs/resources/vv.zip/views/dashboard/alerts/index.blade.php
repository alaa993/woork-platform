@extends('layouts.app')
@section('title','Alerts')
@section('page','Alerts')
@section('content')
<div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-5">
  <ul class="divide-y divide-slate-200/70 dark:divide-white/10">
    @forelse($alerts as $item)
      <li class="py-2 flex items-center justify-between">
        <div>
          <div class="font-medium">{{ $item->message }}</div>
          <div class="text-xs text-slate-500">{{ $item->kind }} · {{ $item->channel }}</div>
        </div>
        <x-badge color="amber">{{ $item->level }}</x-badge>
      </li>
    @empty
      <li class="py-6 text-center text-slate-400">No alerts.</li>
    @endforelse
  </ul>
</div>
@endsection
