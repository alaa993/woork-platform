@extends('layouts.landing')
@section('title','Woork — From video to numbers.')
@section('content')
<section class="relative">
  <div class="mx-auto max-w-7xl px-4 grid lg:grid-cols-2 gap-10 items-center">
    <div class="space-y-6">
      <div class="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 bg-emerald-500/10 px-3 py-1 text-xs">
        <span class="w-2 h-2 rounded-full bg-emerald-500"></span> Privacy-first — no video stored
      </div>
      <h1 class="text-4xl md:text-5xl font-extrabold leading-tight">From <span class="text-emerald-600">video</span> to numbers.</h1>
      <p class="text-lg text-slate-600 dark:text-slate-300">Real-time, anonymous productivity metrics for your team. AI that tracks <b>work</b> — not people.</p>
      <div class="flex flex-wrap items-center gap-3">
        <a href="{{ route('login') }}" class="rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-3 text-sm font-medium shadow-sm shadow-emerald-600/20">Start free trial</a>
        <a href="#pricing" class="rounded-2xl border border-slate-300 dark:border-white/10 px-5 py-3 text-sm hover:bg-slate-100 dark:hover:bg-white/5">See pricing</a>
      </div>
      <div class="grid grid-cols-2 gap-4 pt-2 text-sm">
        <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-4">WhatsApp OTP login</div>
        <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-4">Metrics only — GDPR</div>
      </div>
    </div>
    <div class="relative">
      <div class="absolute -inset-6 rounded-3xl bg-emerald-500/10 blur-2xl -z-10"></div>
      <div class="rounded-3xl border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/5 backdrop-blur p-3 shadow-2xl">
        <img src="{{ asset('assets/img/as.jpg') }}" alt="Dashboard" class="rounded-xl w-full object-cover">
      </div>
      <div class="mt-2 text-xs text-slate-500 dark:text-slate-400 text-center">Illustrative preview — not real data.</div>
    </div>
  </div>
</section>

<section id="features" class="mx-auto max-w-7xl px-4 py-16">
  <h2 class="text-2xl md:text-3xl font-semibold tracking-tight mb-8">Why Woork</h2>
  <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
    @php $features=[
      ['AI tracking','Understands posture, phone use & presence.'],
      ['Privacy-first','Processing in memory; only metrics are stored.'],
      ['Real-time','Live dashboards for rooms, shifts and teams.'],
      ['Smart alerts','Policy-based alerts & thresholds.'],
    ]; @endphp
    @foreach($features as [$title,$desc])
      <div class="group rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-6 hover:shadow-xl transition-shadow">
        <div class="mb-3 h-8 w-8 rounded-md bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
          <x-icon name="dashboard" class="h-4 w-4"/>
        </div>
        <h3 class="font-medium mb-1">{{ $title }}</h3>
        <p class="text-sm text-slate-600 dark:text-slate-300">{{ $desc }}</p>
      </div>
    @endforeach
  </div>
</section>

<section id="pricing" class="mx-auto max-w-7xl px-4 pb-16">
  <h2 class="text-2xl md:text-3xl font-semibold tracking-tight mb-8">Simple pricing</h2>
  <div class="grid md:grid-cols-3 gap-6">
    @php $plans=[
      ['Starter','Free trial','0','3 cameras • 15 employees','Try Woork with WhatsApp OTP','/login'],
      ['Pro','Best for teams','39','10 cameras • 60 employees','Priority support & Export','/login'],
      ['Enterprise','Custom','—','Unlimited','SLA • SSO • Dedicated support','/login'],
    ]; @endphp
    @foreach($plans as [$name,$tag,$price,$limit,$perk,$link])
      <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur p-6 flex flex-col">
        <div class="text-xs text-emerald-700 dark:text-emerald-300">{{ $tag }}</div>
        <h3 class="mt-1 text-xl font-semibold">{{ $name }}</h3>
        <div class="mt-4 text-4xl font-semibold tracking-tight">@if($price==='—')<span class="text-lg">Contact</span>@else ${{ $price }}<span class="text-sm text-slate-500 dark:text-slate-400">/mo</span>@endif</div>
        <ul class="mt-4 space-y-2 text-sm text-slate-700 dark:text-slate-300">
          <li>• {{ $limit }}</li>
          <li>• {{ $perk }}</li>
          <li>• Privacy-first metrics</li>
        </ul>
        <a href="{{ $link }}" class="mt-6 inline-flex justify-center rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2">Get started</a>
      </div>
    @endforeach
  </div>
</section>

<section id="faq" class="mx-auto max-w-5xl px-4 pb-16">
  <h2 class="text-2xl md:text-3xl font-semibold tracking-tight mb-8">FAQ</h2>
  <div class="divide-y divide-slate-200/70 dark:divide-white/10 rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/60 dark:bg-white/5 backdrop-blur">
    <details class="p-6" open>
      <summary class="cursor-pointer font-medium">Do you store video?</summary>
      <p class="mt-2 text-sm text-slate-600 dark:text-slate-300">No. Processing happens in-memory; we only keep metrics.</p>
    </details>
    <details class="p-6">
      <summary class="cursor-pointer font-medium">How do users sign in?</summary>
      <p class="mt-2 text-sm text-slate-600 dark:text-slate-300">Via WhatsApp OTP (standingtech gateway) or email magic-link.</p>
    </details>
    <details class="p-6">
      <summary class="cursor-pointer font-medium">Can I export data?</summary>
      <p class="mt-2 text-sm text-slate-600 dark:text-slate-300">Yes. CSV exports for daily summaries and alerts.</p>
    </details>
  </div>
</section>
@endsection
