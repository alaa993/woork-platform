<!doctype html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->isLocale('ar')?'rtl':'ltr' }}"
  x-data="{open:false,dark:localStorage.theme==='dark'}"
  x-init="document.documentElement.classList.toggle('dark', dark)"
  x-on:darkmode.window="dark=!dark; localStorage.theme=dark?'dark':'light'; document.documentElement.classList.toggle('dark', dark)">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title','Woork — From video to numbers')</title>
  <meta name="description" content="@yield('meta_description','Privacy-first workplace analytics.')">
  <link rel="icon" href="{{ asset('assets/favicon.ico') }}">
  @vite(['resources/css/app.css','resources/js/app.js'])
  <script src="https://unpkg.com/alpinejs@3.x.x" defer></script>
</head>
<body class="bg-white text-slate-800 dark:bg-slate-950 dark:text-slate-100 antialiased">
  <header class="fixed inset-x-0 top-0 z-50">
    <div class="mx-auto max-w-7xl px-4">
      <div class="mt-4 rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04] backdrop-blur shadow-lg">
        <div class="h-14 px-3 flex items-center justify-between">
          <a href="{{ route('landing') }}" class="flex items-center gap-2">
            <img src="{{ asset('assets/img/woork-logo.svg') }}" class="h-8 w-11 rounded-md" alt="">
            
          </a>
          <nav class="hidden md:flex items-center gap-6 text-sm">
            <a href="#features" class="hover:text-emerald-600 dark:hover:text-emerald-400">Features</a>
            <a href="#pricing" class="hover:text-emerald-600 dark:hover:text-emerald-400">Pricing</a>
            <a href="#faq" class="hover:text-emerald-600 dark:hover:text-emerald-400">FAQ</a>
            <a href="{{ route('landing') }}?lang=en">EN</a>
            <a href="{{ route('landing') }}?lang=ar">AR</a>
            <a href="{{ route('landing') }}?lang=tr">TR</a>
            <button class="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/10" x-on:click="$dispatch('darkmode')">Theme</button>
            <a href="{{ route('login') }}" class="rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2">Start</a>
          </nav>
          <button class="md:hidden p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10" @click="open=!open">
            <x-icon name="menu" class="h-5 w-5"/>
          </button>
        </div>
        <div class="md:hidden border-t border-slate-200/70 dark:border-white/10 px-3 py-3" x-show="open" x-collapse>
          <div class="flex flex-col gap-2 text-sm">
            <a href="#features" class="py-1">Features</a>
            <a href="#pricing" class="py-1">Pricing</a>
            <a href="#faq" class="py-1">FAQ</a>
            <div class="flex gap-3 items-center py-2">
              <a href="{{ route('landing') }}?lang=en">EN</a>
              <a href="{{ route('landing') }}?lang=ar">AR</a>
              <a href="{{ route('landing') }}?lang=tr">TR</a>
              <button class="ms-auto rounded-lg border px-2 py-1 text-xs dark:border-white/10" x-on:click="$dispatch('darkmode')">Theme</button>
            </div>
            <a href="{{ route('login') }}" class="rounded-lg bg-emerald-600 text-white px-4 py-2 text-center">Start</a>
          </div>
        </div>
      </div>
    </div>
  </header>
  <main class="pt-28">@yield('content')</main>
  <footer class="mt-20">
    <div class="mx-auto max-w-7xl px-4 py-10 text-sm text-slate-500 dark:text-slate-400 flex flex-col md:flex-row items-center justify-between gap-4 border-t border-slate-200/70 dark:border-white/10">
      <div>© {{ date('Y') }} Woork</div>
      <div class="flex gap-6"><a href="/privacy">Privacy</a><a href="/terms">Terms</a><a href="/contact">Contact</a></div>
    </div>
  </footer>
</body>
</html>
