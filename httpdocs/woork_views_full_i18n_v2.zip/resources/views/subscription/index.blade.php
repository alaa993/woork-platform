@extends('layouts.app')
@section('title','Subscription')
@section('page', __('woork.subscription'))
@section('content')
<div class="grid md:grid-cols-2 gap-4">
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="font-semibold mb-2">Plan</h3>
    <p class="text-sm text-slate-500 mb-4">Trial / Active status will appear here.</p>
    <div class="flex items-center gap-3">
      <form method="POST" action="{{ route('billing.checkout') }}">@csrf
        <button class="px-4 py-2 rounded-xl bg-emerald-600 text-white">{{ __('woork.subscription_checkout') }}</button>
      </form>
      <form method="POST" action="{{ route('billing.portal') }}">@csrf
        <button class="px-4 py-2 rounded-xl border">{{ __('woork.subscription_manage') }}</button>
      </form>
    </div>
  </div>
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="font-semibold mb-2">Limits</h3>
    <ul class="text-sm text-slate-600 dark:text-slate-300 list-disc ms-5">
      <li>Cameras limit</li>
      <li>Employees limit</li>
      <li>Trial days</li>
    </ul>
  </div>
</div>
@endsection
