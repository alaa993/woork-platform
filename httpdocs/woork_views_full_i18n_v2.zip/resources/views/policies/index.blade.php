@extends('layouts.app')
@section('title','Policies')
@section('page', __('woork.policies'))
@section('content')
<form method="POST" action="{{ route('policies.update') }}" class="space-y-6">@csrf @method('PUT')
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="font-semibold mb-3">{{ __('woork.work_hours') }}</h3>
    <textarea name="work_hours" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2" rows="3"></textarea>
  </div>
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="font-semibold mb-3">{{ __('woork.breaks') }}</h3>
    <textarea name="breaks" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2" rows="3"></textarea>
  </div>
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="font-semibold mb-3">{{ __('woork.thresholds') }}</h3>
    <textarea name="thresholds" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2" rows="3"></textarea>
  </div>
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="font-semibold mb-3">{{ __('woork.visibility') }}</h3>
    <textarea name="visibility" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2" rows="3"></textarea>
  </div>
  <button class="px-4 py-2 rounded-xl bg-emerald-600 text-white">{{ __('woork.save') }}</button>
</form>
@endsection
