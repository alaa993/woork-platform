@php($rtl = app()->isLocale('ar'))
<!doctype html>
<html lang="{{ app()->getLocale() }}" dir="{{ $rtl?'rtl':'ltr' }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title','Woork')</title>
  @vite(['resources/css/app.css','resources/js/app.js'])
</head>
<body class="min-h-screen bg-slate-50 text-slate-800 dark:bg-slate-950 dark:text-slate-100 supports-backdrop">
  <header class="border-b border-slate-200/70 dark:border-white/10 bg-translucent backdrop-blur">
    <div class="max-w-7xl mx-auto h-14 px-4 flex items-center justify-between">
      <a href="{{ route('landing') }}" class="inline-flex items-center gap-2">
        <img src="{{ asset('assets/woork-logo.png') }}" class="h-10 w-10 md:h-12 md:w-12 rounded-md select-none" alt="{{ __('woork.woork') }}">
        <strong class="text-xl md:text-2xl">woork</strong>
      </a>
      <nav class="hidden md:flex items-center gap-3 text-sm">
        <a class="px-3 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10" href="#why">{{ __('woork.why_woork') }}</a>
        <a class="px-3 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10" href="{{ route('login') }}">{{ __('woork.login') }}</a>
      </nav>
    </div>
  </header>
  @yield('content')
</body>
</html>
