<!doctype html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->isLocale('ar')?'rtl':'ltr' }}"
  x-data="{dark:localStorage.theme==='dark', open:false}"
  x-init="document.documentElement.classList.toggle('dark', dark)"
  x-on:darkmode.window="dark=!dark; localStorage.theme=dark?'dark':'light'; document.documentElement.classList.toggle('dark', dark)">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title','Woork Console')</title>
  @vite(['resources/css/app.css','resources/js/app.js'])
  <script src="https://unpkg.com/alpinejs@3.x.x" defer></script>
</head>
<body class="min-h-screen bg-slate-50 text-slate-800 dark:bg-slate-950 dark:text-slate-100 antialiased supports-backdrop">
  <header class="sticky top-0 z-40 bg-translucent backdrop-blur border-b border-slate-200/70 dark:border-white/10">
    <div class="max-w-7xl mx-auto h-14 px-4 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <button class="md:hidden p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10" @click="open=!open" aria-label="Toggle menu"><x-icon name="menu"/></button>
        <a href="{{ route('app') }}" class="flex items-center gap-2">
          <img src="{{ asset('assets/woork-logo.png') }}" class="h-9 w-9 md:h-10 md:w-10 rounded-md select-none" alt="{{ __('woork.woork') }}">
          <strong>woork</strong>
        </a>
        <span class="hidden sm:inline text-xs text-slate-500 dark:text-slate-400 border-s ms-3 ps-3">{{ __('woork.console') }}</span>
      </div>
      <div class="flex items-center gap-2">
        <form method="POST" action="{{ route('settings.language') }}" class="hidden md:flex items-center gap-2">@csrf
          <select name="lang" class="rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-2 py-1 text-xs">
            <option value="en" @selected(app()->getLocale()==='en')>EN</option>
            <option value="ar" @selected(app()->getLocale()==='ar')>AR</option>
            <option value="tr" @selected(app()->getLocale()==='tr')>TR</option>
          </select>
          <button class="rounded-lg border px-2 py-1 text-xs hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/10">{{ __('woork.switch') }}</button>
        </form>
        <button class="rounded-lg border px-2 py-1 text-xs hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/10" x-on:click="$dispatch('darkmode')">{{ __('woork.theme') }}</button>
        <form method="POST" action="{{ route('logout') }}">@csrf
          <button class="rounded-lg border px-3 py-1.5 text-xs hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/10">{{ __('woork.logout') }}</button>
        </form>
      </div>
    </div>
  </header>

  <div class="max-w-7xl mx-auto grid md:grid-cols-[240px_1fr] gap-4 px-4 py-4">
    <!-- Sidebar -->
    <aside class="md:sticky md:top-16 md:h-[calc(100dvh-6rem)] p-3 rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04] backdrop-blur shadow-sm"
           :class="{'hidden': !open, 'block': open, 'md:block': true}">
      @php($role = auth()->user()->role ?? 'company_admin')
      @php($menu = match($role){
        'super_admin' => [
          ['icon'=>'dashboard','label'=>__('woork.dashboard'),'route'=>'app'],
          ['icon'=>'admin','label'=>__('woork.users'),'route'=>'admin.users'],
          ['icon'=>'export','label'=>__('woork.export_csv'),'route'=>'export.daily.csv'],
          ['icon'=>'settings','label'=>__('woork.settings'),'route'=>'settings.index'],
        ],
        'employee' => [
          ['icon'=>'dashboard','label'=>__('woork.my_dashboard'),'route'=>'app'],
          ['icon'=>'bell','label'=>__('woork.alerts'),'route'=>'alerts.index'],
          ['icon'=>'settings','label'=>__('woork.settings'),'route'=>'settings.index'],
        ],
        default => [
          ['icon'=>'dashboard','label'=>__('woork.dashboard'),'route'=>'app'],
          ['icon'=>'rooms','label'=>__('woork.rooms'),'route'=>'rooms.index'],
          ['icon'=>'camera','label'=>__('woork.cameras'),'route'=>'cameras.index'],
          ['icon'=>'users','label'=>__('woork.employees'),'route'=>'employees.index'],
          ['icon'=>'bell','label'=>__('woork.alerts'),'route'=>'alerts.index'],
          ['icon'=>'policy','label'=>__('woork.policies'),'route'=>'policies.index'],
          ['icon'=>'billing','label'=>__('woork.subscription'),'route'=>'subscription.index'],
          ['icon'=>'export','label'=>__('woork.export_csv'),'route'=>'export.daily.csv'],
          ['icon'=>'settings','label'=>__('woork.settings'),'route'=>'settings.index'],
        ]
      })
      @endphp
      <nav class="text-sm">
        @foreach($menu as $item)
          @php($active = request()->routeIs($item['route'].'*'))
          <a href="{{ route($item['route']) }}"
             class="flex items-center gap-2 px-3 py-2 rounded-xl my-1 hover:bg-slate-100 dark:hover:bg-white/10 {{ $active ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : '' }}">
            <x-icon :name="$item[icon]" class="h-4 w-4"/>
            <span>{{ $item['label'] }}</span>
          </a>
        @endforeach
      </nav>
    </aside>

    <!-- Main -->
    <section>
      <div class="mb-3 flex items-center justify-between">
        <h1 class="text-lg font-semibold">@yield('page','')</h1>
        @yield('actions')
      </div>
      @include('partials.flash')
      @yield('content')
    </section>
  </div>
</body>
</html>
