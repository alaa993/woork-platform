@extends('layouts.app')
@section('title','Edit Employees')
@section('page', __('woork.employees'))
@section('content')
  @include('partials.flash')
  <form method="POST" action="{ route('employees.update', $item) }" class="space-y-4">@csrf @method('PUT')
    
<div class="grid md:grid-cols-2 gap-4">
  <div><label class="block text-sm mb-1">{{ __('woork.name') }}</label>
    <input name="name" value="{{ old('name',$item->name ?? '') }}" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2" required></div>
  <div><label class="block text-sm mb-1">{{ __('woork.title') }}</label>
    <input name="title" value="{{ old('title',$item->title ?? '') }}" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2"></div>
  <div><label class="block text-sm mb-1">{{ __('woork.room') }}</label>
    <select name="room_id" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2">
      @foreach($rooms as $room)<option value="{{ $room->id }}" @selected(old('room_id',$item->room_id ?? null)==$room->id)>{{ $room->name }}</option>@endforeach
    </select></div>
</div>

    <div class="flex items-center gap-3">
      <button class="px-4 py-2 rounded-xl bg-emerald-600 text-white">{ __('woork.update') }</button>
      <a href="{ route('employees.index') }" class="px-4 py-2 rounded-xl border">{ __('woork.cancel') }</a>
    </div>
  </form>
@endsection
