@extends('layouts.app')
@section('title','Employees')
@section('page', __('woork.employees'))
@section('actions')
  <a href="{ route('employees.create') }" class="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-sm hover:bg-emerald-700">{ __('woork.add') }</a>
@endsection
@section('content')

<div class="rounded-xl border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
  <div class="p-3 flex items-center justify-between">
    <form class="flex items-center gap-2">
      <input name="q" class="rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2 text-sm" placeholder="{ __('woork.search') }">
    </form>
    <a href="{ route('employees.create') }" class="px-3 py-2 rounded-xl bg-emerald-600 text-white text-sm hover:bg-emerald-700">{ __('woork.add') }</a>
  </div>
  <div class="overflow-x-auto">
    <table class="min-w-full text-sm">
      <thead><tr><th class="px-3 py-2 text-left text-xs font-medium text-slate-500">{ __('woork.name') if c!='actions' else __('woork.actions') }</th><th class="px-3 py-2 text-left text-xs font-medium text-slate-500">{ __('woork.title') if c!='actions' else __('woork.actions') }</th><th class="px-3 py-2 text-left text-xs font-medium text-slate-500">{ __('woork.room') if c!='actions' else __('woork.actions') }</th><th class="px-3 py-2 text-left text-xs font-medium text-slate-500">{ __('woork.status') if c!='actions' else __('woork.actions') }</th><th class="px-3 py-2 text-left text-xs font-medium text-slate-500">{ __('woork.actions') if c!='actions' else __('woork.actions') }</th></tr></thead>
      <tbody>
@forelse($items as $item)
<tr class="border-t border-slate-200/50 dark:border-white/5">
  <td class="px-3 py-2">{{ $item->name }}</td>
  <td class='px-3 py-2'>{{ optional($item->room)->name }}</td><td class='px-3 py-2'>{{ $item->title }}</td><td class='px-3 py-2'>{{ $item->status ?? '-' }}</td>
  <td class="px-3 py-2">
    <div class="flex gap-2">
      <a href="{{ route('employees.edit',$item) }}" class="px-2 py-1 rounded-lg border text-xs">{{ __('woork.edit') }}</a>
      <form method="POST" action="{{ route('employees.destroy',$item) }}" onsubmit="return confirm('Delete?')">@csrf @method('DELETE')
        <button class="px-2 py-1 rounded-lg border text-xs">{{ __('woork.delete') }}</button>
      </form>
    </div>
  </td>
</tr>
@empty
<tr><td class="px-3 py-6 text-slate-500" colspan="10">No data</td></tr>
@endforelse
</tbody>
    </table>
  </div>
  @if(method_exists($items,'links'))
    <div class="p-3">{ $items->links() }</div>
  @endif
</div>

@endsection
