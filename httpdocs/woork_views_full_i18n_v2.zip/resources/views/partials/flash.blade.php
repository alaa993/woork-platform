@if (session('status'))
  <div class="mb-3 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 px-3 py-2">{{ session('status') }}</div>
@endif
@if (session('error'))
  <div class="mb-3 rounded-lg bg-rose-50 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300 px-3 py-2">{{ session('error') }}</div>
@endif
@if ($errors->any())
  <div class="mb-3 rounded-lg bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300 px-3 py-2">
    <ul class="list-disc ms-4 my-1">
      @foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
  </div>
@endif
