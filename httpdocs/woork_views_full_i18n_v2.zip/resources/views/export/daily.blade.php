@extends('layouts.app')
@section('title','Export')
@section('page', __('woork.export_csv'))
@section('content')
<a href="{{ route('export.daily.csv') }}" class="px-4 py-2 rounded-xl bg-emerald-600 text-white">CSV</a>
@endsection
