@extends('layouts.app')
@section('title','Alerts')
@section('page', __('woork.alerts'))
@section('content')
<div class="rounded-xl border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
  <div class="p-4 text-sm text-slate-500">{{ __('woork.no_alerts') }}</div>
</div>
@endsection
