@extends('layouts.public')
@section('title', __('woork.login'))
@section('content')
<section class="max-w-md mx-auto px-4 py-10">
  @include('partials.flash')
  <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04] backdrop-blur p-6">
    <h1 class="text-xl font-semibold mb-4">{{ __('woork.login') }}</h1>
    <form method="POST" action="{{ route('otp.request') }}" class="space-y-4">@csrf
      <label class="block text-sm">{{ __('woork.phone') }}</label>
      <input name="phone" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2" placeholder="+1 555 123 4567" required>
      <div class="flex items-center gap-3">
        <button class="px-4 py-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700">{{ __('woork.send_code') }}</button>
        <a href="{{ route('landing') }}" class="px-4 py-2 rounded-xl border border-slate-300 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/10">{{ __('woork.cancel') }}</a>
      </div>
    </form>

    <form method="POST" action="{{ route('otp.verify') }}" class="mt-6 space-y-4">@csrf
      <input type="hidden" name="phone" value="{{ old('phone') }}">
      <label class="block text-sm">OTP</label>
      <input name="code" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2" placeholder="123456" required>
      <button class="px-4 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900">{{ __('woork.verify') }}</button>
    </form>
  </div>
</section>
@endsection
