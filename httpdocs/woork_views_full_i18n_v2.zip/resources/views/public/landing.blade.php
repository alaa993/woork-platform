@extends('layouts.public')
@section('title','Woork')
@section('content')
<section class="max-w-7xl mx-auto px-4 py-12 grid md:grid-cols-2 gap-8 items-center">
  <div>
    <h1 class="text-3xl md:text-5xl font-extrabold mb-4">{{ __('woork.from_video_to_numbers') }}</h1>
    <p class="text-slate-600 dark:text-slate-300 mb-6">{{ __('woork.subheadline') }}</p>
    <div class="flex items-center gap-3">
      <a href="{{ route('login') }}" class="px-4 py-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700">{{ __('woork.start_free_trial') }}</a>
      <a href="{{ route('subscription.index') }}" class="px-4 py-2 rounded-xl border border-slate-300 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/10">{{ __('woork.see_pricing') }}</a>
    </div>
    <p class="text-xs mt-4 opacity-70">{{ __('woork.privacy_first') }}</p>
    <p class="text-xs opacity-70">{{ __('woork.whatsapp_otp') }}</p>
  </div>
  <div class="rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04] backdrop-blur p-6">
    <div class="h-48 grid place-items-center text-slate-400">{{ __('woork.illustrative') }}</div>
  </div>
</section>
@endsection
