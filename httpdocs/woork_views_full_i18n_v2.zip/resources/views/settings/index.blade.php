@extends('layouts.app')
@section('title','Settings')
@section('page', __('woork.settings'))
@section('content')
<div class="grid md:grid-cols-2 gap-4">
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="font-semibold mb-3">{{ __('woork.general') }}</h3>
    <p class="text-sm text-slate-500">{{ __('woork.settings_saved') }}</p>
  </div>
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="font-semibold mb-3">{{ __('woork.language_label') }}</h3>
    <form method="POST" action="{{ route('settings.language') }}" class="flex items-center gap-2">@csrf
      <select name="lang" class="rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-2 py-1 text-sm">
        <option value="en" @selected(app()->getLocale()==='en')>EN</option>
        <option value="ar" @selected(app()->getLocale()==='ar')>AR</option>
        <option value="tr" @selected(app()->getLocale()==='tr')>TR</option>
      </select>
      <button class="rounded-lg border px-3 py-2 text-sm">{{ __('woork.submit') }}</button>
    </form>
  </div>
</div>
@endsection
