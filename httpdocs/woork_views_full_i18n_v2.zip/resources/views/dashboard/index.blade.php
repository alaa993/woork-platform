@extends('layouts.app')
@section('title','Dashboard')
@section('page', __('woork.dashboard'))
@section('content')
<div class="grid md:grid-cols-3 gap-4">
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <div class="text-sm text-slate-500 mb-2">{{ __('woork.today_score') }}</div>
    <div class="text-3xl font-bold">{{ $score ?? 0 }}</div>
  </div>
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <div class="text-sm text-slate-500 mb-2">{{ __('woork.active_employees') }}</div>
    <div class="text-3xl font-bold">{{ $employees ?? 0 }}</div>
  </div>
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <div class="text-sm text-slate-500 mb-2">{{ __('woork.phone_events') }}</div>
    <div class="text-3xl font-bold">{{ $events ?? 0 }}</div>
  </div>
</div>

<div class="mt-8 grid md:grid-cols-2 gap-4">
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="text-sm font-semibold mb-3">{{ __('woork.weekly_score') }}</h3>
    <div class="h-40 grid place-items-center text-slate-400">Chart placeholder</div>
  </div>
  <div class="rounded-xl p-4 border border-slate-200/70 dark:border-white/10 bg-white/70 dark:bg-white/[0.04]">
    <h3 class="text-sm font-semibold mb-3">{{ __('woork.recent_alerts') }}</h3>
    <p class="text-slate-500 text-sm">{{ __('woork.no_alerts') }}</p>
  </div>
</div>
@endsection
