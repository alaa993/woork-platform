@extends('layouts.app')
@section('title','Create Rooms')
@section('page', __('woork.rooms'))
@section('content')
  @include('partials.flash')
  <form method="POST" action="{ route('rooms.store') }" class="space-y-4">@csrf
    
<div class="grid md:grid-cols-2 gap-4">
  <div><label class="block text-sm mb-1">{{ __('woork.name') }}</label>
    <input name="name" value="{{ old('name',$item->name ?? '') }}" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2" required></div>
  <div><label class="block text-sm mb-1">{{ __('woork.location') }}</label>
    <input name="location" value="{{ old('location',$item->location ?? '') }}" class="w-full rounded-lg border border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2"></div>
</div>

    <div class="flex items-center gap-3">
      <button class="px-4 py-2 rounded-xl bg-emerald-600 text-white">{ __('woork.save') }</button>
      <a href="{ route('rooms.index') }" class="px-4 py-2 rounded-xl border">{ __('woork.cancel') }</a>
    </div>
  </form>
@endsection
