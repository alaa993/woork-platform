<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Cashier\Billable;

class User extends Authenticatable {
  use Notifiable, Billable;
  protected $fillable=['organization_id','name','email','phone','role','password'];
  protected $hidden=['password'];
  public function organization(){ return $this->belongsTo(Organization::class); }
}
