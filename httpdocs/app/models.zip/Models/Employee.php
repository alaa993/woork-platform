<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $fillable = [
        'organization_id',
        'room_id',
        'name',
        'title',
        'photos',
        'is_active',
    ];

    protected $casts = [
        'photos' => 'array',
        'is_active' => 'boolean',
    ];

    // 🔹 العلاقة مع الغرفة (Room)
    public function room()
    {
        return $this->belongsTo(Room::class);
    }

    // 🔹 العلاقة مع المنظمة (Organization)
    public function organization()
    {
        return $this->belongsTo(Organization::class);
    }

    // 🔹 علاقة المراقبة أو الأحداث (Events)
    public function events()
    {
        return $this->hasMany(Event::class);
    }
}